(function(e,t){Object.defineProperty(e,Symbol.toStringTag,{value:`Module`});function n(e){"@swc/helpers - typeof";return e&&typeof Symbol<`u`&&e.constructor===Symbol?`symbol`:typeof e}var r={SparklesIcon:[`MagicWandIcon`],SparkleIcon:[`MagicWandIcon`]};function i(...e){return s(e,!1)}function a(...e){return s(e,!0)}function o(e){try{return e()}catch{return}}function s(e,i){var a=function(e){var n=o(function(){return c(e)||void 0}),r=o(function(){return f?.(e)});if(i)return d&&(r||n)?{v:(0,t.jsx)(d,{source:n,IconComponent:r,variant:`danger`})}:`continue`;if(n&&d)return{v:(0,t.jsx)(d,{source:n})};if(r)return{v:(0,t.jsx)(r,{})}},s=[...new Set(e.flatMap(function(e){return[e,...r[e]??[]]}))],{getAssetIdByName:c}=revenge.assets,{TableRow:l,TableRowIcon:u}=revenge.discord.design.Design,d=l?.Icon??u,f=o(function(){return revenge.utils.discord.lookupGeneratedIconComponent});for(var p of s){var m=a(p);if(n(m)===`object`)return m.v}}function c(e=16){try{var t=revenge.externals.ReactNativeSafeAreaContext?.useSafeAreaInsets?.();if(typeof t?.bottom==`number`)return t.bottom+e}catch{}return e}var l=20,u,d=[],f=new Set;function p(e){if(u=e,e)for(var t of d.splice(0))h(t)}function m(e,t){var n=g(e,t),r=n instanceof Error?n.message:String(n);f.has(r)||(f.add(r),u?h(n):d.length<l&&d.push(n))}function h(e){try{u?.reportError(e)}catch{}}function g(e,t){if(t===void 0)return Error(e);if(!e)return t;var n=t instanceof Error?t.message:String(t),r=Error(`${e} ${n}`);if(t instanceof Error&&typeof t.stack==`string`){var i=t.stack.split(`
`).slice(1).join(`
`);i&&(r.stack=`${r.name}: ${r.message}\n${i}`)}return r}var _,v=`changelogSeenVersion`,y=3,b=function(e){return`${e}.changelog`};function ee(e){return typeof e==`string`?e:e&&Array.isArray(e.nums)?e.nums.join(`.`)+(e.label?`-${e.label}`:``):String(e??``)}function te(e){var[t,n]=String(e).split(`-`,2);return{nums:t.split(`.`).map(function(e){return Number.parseInt(e,10)||0}),pre:n}}function x(e,t){for(var n=te(e),r=te(t),i=0;i<Math.max(n.nums.length,r.nums.length);i++){var a=(n.nums[i]??0)-(r.nums[i]??0);if(a)return a}return n.pre===r.pre?0:n.pre===void 0?1:r.pre===void 0?-1:n.pre.localeCompare(r.pre,void 0,{numeric:!0})}function ne(e,t,n={}){var r=e.plugin.manifest,i={id:r.id,name:r.name??r.id,current:ee(r.version),entries:[...t].sort(function(e,t){return x(t.version,e.version)}),storage:e.jsonStorage,latestOnly:n.latestOnly};_=i;var a=ue(i);return re(i).catch(function(e){return m(`[${i.name}] changelog check failed:`,e)}),function(){_===i&&(_=void 0),a()}}async function re(e){if(e.storage){var t=await e.storage.get(),n=t?.[v]?ee(t[v]):void 0;if(n!==e.current){if(!n||x(e.current,n)<0){await e.storage.set({[v]:e.current});return}var r=e.entries.filter(function(t){return x(t.version,n)>0&&x(t.version,e.current)<=0});r.length?e.pending=e.latestOnly?r.slice(0,1):r:await e.storage.set({[v]:e.current})}}}function ie(e={}){var{React:n}=revenge.react,{useNavigation:r}=revenge.externals.ReactNavigation.ReactNavigationNative,i=r(),a=e.header!==!1;n.useLayoutEffect(function(){a&&_&&i.setOptions?.({headerRight:function(){return(0,t.jsx)(ae,{})}})},[a]),n.useEffect(function(){var e=_;if(e?.pending?.length){var t=e.pending;e.pending=void 0,ce(e,t,function(){return i.navigate(b(e.id))}),e.storage?.set({[v]:e.current}).catch(function(t){return m(`[${e.name}] could not save the seen version:`,t)})}},[])}function ae(){var{Pressable:e}=revenge.react.ReactNative,{useNavigation:n}=revenge.externals.ReactNavigation.ReactNavigationNative,r=n(),a=_;return a?(0,t.jsx)(e,{accessibilityRole:`button`,accessibilityLabel:`Changelog`,hitSlop:12,onPress:function(){return r.navigate(b(a.id))},style:function({pressed:e}){return{paddingHorizontal:12,opacity:e?.5:1}},children:i(`ClockIcon`,`ic_clock`)}):null}function oe({changes:e}){var{View:n}=revenge.react.ReactNative,{Text:r}=revenge.discord.design.Design;return(0,t.jsx)(n,{style:{gap:4},children:e.map(function(e,i){return(0,t.jsxs)(n,{style:{flexDirection:`row`},children:[(0,t.jsx)(r,{variant:`text-sm/normal`,color:`text-muted`,style:{width:14},children:`•`}),(0,t.jsx)(r,{variant:`text-sm/normal`,color:`text-muted`,style:{flex:1},children:e})]},i)})})}function se(e){return e.title?`${e.version} · ${e.title}`:e.version}function ce(e,n,r){var{ScrollView:i,View:a,Dimensions:o}=revenge.react.ReactNative,{AlertModal:s,AlertActionButton:c,Text:l}=revenge.discord.design.Design,u=revenge.discord.actions.AlertActionCreators,d=`bleelblep-whats-new-${e.id}`,f=function(){return u.dismissAlert(d)},p=n.slice(0,y),h=n.length-p.length,g=(0,t.jsx)(i,{style:{maxHeight:Math.round(o.get(`window`).height*.5)},nestedScrollEnabled:!0,children:(0,t.jsxs)(a,{style:{gap:12},children:[p.map(function(e){return(0,t.jsxs)(a,{style:{gap:4},children:[(0,t.jsx)(l,{variant:`text-sm/semibold`,color:`text-default`,children:se(e)}),(0,t.jsx)(oe,{changes:e.changes})]},e.version)}),h>0?(0,t.jsxs)(l,{variant:`text-sm/normal`,color:`text-muted`,children:[`And `,h,` more version`,h===1?``:`s`,` in the full changelog.`]}):null]})});try{u.openAlert(d,(0,t.jsx)(s,{title:`What's new in ${e.name} ${e.current}`,extraContent:g,actions:(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(c,{text:`Full changelog`,variant:`primary`,onPress:function(){f(),r()}}),(0,t.jsx)(c,{text:`Close`,variant:`secondary`,onPress:f})]})}))}catch(t){m(`[${e.name}] couldn't show what's new:`,t)}}function le(){var e=revenge.discord.modules.settings;if(typeof e.refreshSettings==`function`){e.refreshSettings();return}e.refreshSettingsNavigator?.(),e.refreshSettingsOverviewScreen?.()}function ue(e){var{registerSettingsItem:t,onSettingsModulesLoaded:n}=revenge.discord.modules.settings,r=b(e.id),i,a=n(function(){i=t(r,{parent:null,type:`route`,useTitle:function(){return`Changelog`},screen:{route:r,getComponent:function(){return de}}}),le()});return function(){a(),i?.(),i=void 0,le()}}function de(){var{Page:e}=revenge.components,{ScrollView:n,View:r}=revenge.react.ReactNative,{Stack:i,Text:a,TableRowGroup:o,TableRow:s}=revenge.discord.design.Design,l=c(),u=_;return u?(0,t.jsx)(e,{children:(0,t.jsx)(n,{contentContainerStyle:{paddingBottom:l},children:(0,t.jsxs)(i,{spacing:24,children:[(0,t.jsxs)(a,{color:`text-muted`,variant:`text-sm/normal`,children:[`Every version of `,u.name,`, newest first. You have `,u.current,`.`]}),u.entries.map(function(e){var n=e.version===u.current?` · installed`:``;return(0,t.jsx)(o,{title:`${e.version}${n}${e.date?` · ${e.date}`:``}`,children:(0,t.jsx)(s,{label:e.title??`Version ${e.version}`,subLabel:(0,t.jsx)(r,{style:{marginTop:6},children:(0,t.jsx)(oe,{changes:e.changes})})})},e.version)})]})})}):null}var fe=[{version:`0.2.0`,date:`2026-10-25`,title:`Search any country or city`,changes:[`Type a country (Kenya, UK, New Zealand) to get its timezones, even offline.`,`Every timezone is searchable now, by city, region (Indiana) or old name (Calcutta).`,`Any town or city works too, found online through Open-Meteo. Turn it off under Lookups.`,`The place you pick is saved and shown, like "Mombasa, Kenya".`]},{version:`0.1.3`,date:`2026-10-23`,title:`Discord version limit removed`,changes:[`Installs on any Discord version again.`]},{version:`0.1.2`,date:`2026-10-22`,title:`Discord 352.2`,changes:[`Also starts on Discord 352.2 (was 351.6 or older).`]},{version:`0.1.1`,date:`2026-10-21`,title:`Discord version limit`,changes:[`Only starts on Discord 351.6 or older, so a newer Discord build can't break it.`]},{version:`0.1.0`,date:`2026-10-15`,title:`First version`,changes:[`Set someone's timezone from the message long-press menu or settings.`,`Their local time shows after the timestamp on their messages, with their weekday when it differs.`,`People you haven't set can come from the shared timezone list, which you can turn off.`]}];function pe(e,t,n,r=`[modules]`){var i=!1,a=[],o=function(){for(var e of a.splice(0))try{e()}catch{}},s=function(t,a){if(!i&&t){i=!0,Promise.resolve().then(o);try{n(t)}catch(t){m(`${r} patching ${e} failed:`,t)}}};try{var c=revenge.discord.utils.modules.finders;a.push(c.getModuleWithImportedPath(e,function(e){return s(e,`path`)}))}catch(t){m(`${r} path lookup for ${e} failed:`,t)}if(!i&&t)try{a.push(revenge.modules.finders.getModules(t,function(e){return s(e,`name`)},{returnNamespace:!0}))}catch(t){m(`${r} name lookup for ${e} failed:`,t)}return function(){i=!0,o()}}var me=`[Timezones]`,he=`​`,ge,_e=!1;function ve(){var{withProps:e}=revenge.modules.finders.filters,t=function(e){if(e){if(typeof e?.getOrCreate==`function`&&typeof e?.commit==`function`)return e;if(typeof e?.default?.getOrCreate==`function`&&typeof e?.default?.commit==`function`)return e.default;if(typeof e?._channelMessages?.getOrCreate==`function`&&typeof e?._channelMessages?.commit==`function`)return e._channelMessages}};return pe(`lib/ChannelMessages.tsx`,e(`getOrCreate`,`commit`),function(e){var n=t(e);n&&(ge=n)},me)}function ye(e,t){try{var n=ge;if(!n)return!1;var r=n.getOrCreate(e);if(typeof r?.has!=`function`||!r.has(t)||typeof r.update!=`function`)return!1;var i=r.update(t,function(e){try{if(e?.id!==t)return e;var n=Object.create(Object.getPrototypeOf(e));return Object.defineProperties(n,Object.getOwnPropertyDescriptors(e)),typeof n.content==`string`&&(n.content=n.content.endsWith(he)?n.content.slice(0,-he.length):n.content+he),n}catch{return e}});return n.commit(i),_e||(_e=!0,queueMicrotask(function(){_e=!1;try{revenge.discord.flux.Stores.MessageStore?.emitChange?.()}catch(e){m(`${me} redraw emit failed:`,e)}})),!0}catch(e){return m(`${me} redraw failed:`,e),!1}}var S={AD:`Andorra`,AE:`United Arab Emirates`,AF:`Afghanistan`,AG:`Antigua & Barbuda`,AI:`Anguilla`,AL:`Albania`,AM:`Armenia`,AO:`Angola`,AQ:`Antarctica`,AR:`Argentina`,AS:`Samoa (American)`,AT:`Austria`,AU:`Australia`,AW:`Aruba`,AX:`Åland Islands`,AZ:`Azerbaijan`,BA:`Bosnia & Herzegovina`,BB:`Barbados`,BD:`Bangladesh`,BE:`Belgium`,BF:`Burkina Faso`,BG:`Bulgaria`,BH:`Bahrain`,BI:`Burundi`,BJ:`Benin`,BL:`St Barthelemy`,BM:`Bermuda`,BN:`Brunei`,BO:`Bolivia`,BQ:`Caribbean NL`,BR:`Brazil`,BS:`Bahamas`,BT:`Bhutan`,BV:`Bouvet Island`,BW:`Botswana`,BY:`Belarus`,BZ:`Belize`,CA:`Canada`,CC:`Cocos (Keeling) Islands`,CD:`Congo (Dem. Rep.)`,CF:`Central African Rep.`,CG:`Congo (Rep.)`,CH:`Switzerland`,CI:`Côte d’Ivoire`,CK:`Cook Islands`,CL:`Chile`,CM:`Cameroon`,CN:`China`,CO:`Colombia`,CR:`Costa Rica`,CU:`Cuba`,CV:`Cape Verde`,CW:`Curaçao`,CX:`Christmas Island`,CY:`Cyprus`,CZ:`Czech Republic`,DE:`Germany`,DJ:`Djibouti`,DK:`Denmark`,DM:`Dominica`,DO:`Dominican Republic`,DZ:`Algeria`,EC:`Ecuador`,EE:`Estonia`,EG:`Egypt`,EH:`Western Sahara`,ER:`Eritrea`,ES:`Spain`,ET:`Ethiopia`,FI:`Finland`,FJ:`Fiji`,FK:`Falkland Islands`,FM:`Micronesia`,FO:`Faroe Islands`,FR:`France`,GA:`Gabon`,GB:`Britain (UK)`,GD:`Grenada`,GE:`Georgia`,GF:`French Guiana`,GG:`Guernsey`,GH:`Ghana`,GI:`Gibraltar`,GL:`Greenland`,GM:`Gambia`,GN:`Guinea`,GP:`Guadeloupe`,GQ:`Equatorial Guinea`,GR:`Greece`,GS:`South Georgia & the South Sandwich Islands`,GT:`Guatemala`,GU:`Guam`,GW:`Guinea-Bissau`,GY:`Guyana`,HK:`Hong Kong`,HM:`Heard Island & McDonald Islands`,HN:`Honduras`,HR:`Croatia`,HT:`Haiti`,HU:`Hungary`,ID:`Indonesia`,IE:`Ireland`,IL:`Israel`,IM:`Isle of Man`,IN:`India`,IO:`British Indian Ocean Territory`,IQ:`Iraq`,IR:`Iran`,IS:`Iceland`,IT:`Italy`,JE:`Jersey`,JM:`Jamaica`,JO:`Jordan`,JP:`Japan`,KE:`Kenya`,KG:`Kyrgyzstan`,KH:`Cambodia`,KI:`Kiribati`,KM:`Comoros`,KN:`St Kitts & Nevis`,KP:`Korea (North)`,KR:`Korea (South)`,KW:`Kuwait`,KY:`Cayman Islands`,KZ:`Kazakhstan`,LA:`Laos`,LB:`Lebanon`,LC:`St Lucia`,LI:`Liechtenstein`,LK:`Sri Lanka`,LR:`Liberia`,LS:`Lesotho`,LT:`Lithuania`,LU:`Luxembourg`,LV:`Latvia`,LY:`Libya`,MA:`Morocco`,MC:`Monaco`,MD:`Moldova`,ME:`Montenegro`,MF:`St Martin (French)`,MG:`Madagascar`,MH:`Marshall Islands`,MK:`North Macedonia`,ML:`Mali`,MM:`Myanmar (Burma)`,MN:`Mongolia`,MO:`Macau`,MP:`Northern Mariana Islands`,MQ:`Martinique`,MR:`Mauritania`,MS:`Montserrat`,MT:`Malta`,MU:`Mauritius`,MV:`Maldives`,MW:`Malawi`,MX:`Mexico`,MY:`Malaysia`,MZ:`Mozambique`,NA:`Namibia`,NC:`New Caledonia`,NE:`Niger`,NF:`Norfolk Island`,NG:`Nigeria`,NI:`Nicaragua`,NL:`Netherlands`,NO:`Norway`,NP:`Nepal`,NR:`Nauru`,NU:`Niue`,NZ:`New Zealand`,OM:`Oman`,PA:`Panama`,PE:`Peru`,PF:`French Polynesia`,PG:`Papua New Guinea`,PH:`Philippines`,PK:`Pakistan`,PL:`Poland`,PM:`St Pierre & Miquelon`,PN:`Pitcairn`,PR:`Puerto Rico`,PS:`Palestine`,PT:`Portugal`,PW:`Palau`,PY:`Paraguay`,QA:`Qatar`,RE:`Réunion`,RO:`Romania`,RS:`Serbia`,RU:`Russia`,RW:`Rwanda`,SA:`Saudi Arabia`,SB:`Solomon Islands`,SC:`Seychelles`,SD:`Sudan`,SE:`Sweden`,SG:`Singapore`,SH:`St Helena`,SI:`Slovenia`,SJ:`Svalbard & Jan Mayen`,SK:`Slovakia`,SL:`Sierra Leone`,SM:`San Marino`,SN:`Senegal`,SO:`Somalia`,SR:`Suriname`,SS:`South Sudan`,ST:`Sao Tome & Principe`,SV:`El Salvador`,SX:`St Maarten (Dutch)`,SY:`Syria`,SZ:`Eswatini (Swaziland)`,TC:`Turks & Caicos Is`,TD:`Chad`,TF:`French S. Terr.`,TG:`Togo`,TH:`Thailand`,TJ:`Tajikistan`,TK:`Tokelau`,TL:`East Timor`,TM:`Turkmenistan`,TN:`Tunisia`,TO:`Tonga`,TR:`Turkey`,TT:`Trinidad & Tobago`,TV:`Tuvalu`,TW:`Taiwan`,TZ:`Tanzania`,UA:`Ukraine`,UG:`Uganda`,UM:`US minor outlying islands`,US:`United States`,UY:`Uruguay`,UZ:`Uzbekistan`,VA:`Vatican City`,VC:`St Vincent`,VE:`Venezuela`,VG:`Virgin Islands (UK)`,VI:`Virgin Islands (US)`,VN:`Vietnam`,VU:`Vanuatu`,WF:`Wallis & Futuna`,WS:`Samoa (western)`,YE:`Yemen`,YT:`Mayotte`,ZA:`South Africa`,ZM:`Zambia`,ZW:`Zimbabwe`},be=`AD|Europe/Andorra|
AE|Asia/Dubai|
AF|Asia/Kabul|
AG|America/Antigua|
AI|America/Anguilla|
AL|Europe/Tirane|
AM|Asia/Yerevan|
AO|Africa/Luanda|
AQ|Antarctica/McMurdo|New Zealand time - McMurdo, South Pole
AQ|Antarctica/Casey|Casey
AQ|Antarctica/Davis|Davis
AQ|Antarctica/DumontDUrville|Dumont-d'Urville
AQ|Antarctica/Mawson|Mawson
AQ|Antarctica/Palmer|Palmer
AQ|Antarctica/Rothera|Rothera
AQ|Antarctica/Syowa|Syowa
AQ|Antarctica/Troll|Troll
AQ|Antarctica/Vostok|Vostok
AR|America/Argentina/Buenos_Aires|Buenos Aires (BA, CF)
AR|America/Argentina/Cordoba|Argentina (most areas: CB, CC, CN, ER, FM, MN, SE, SF)
AR|America/Argentina/Salta|Salta (SA, LP, NQ, RN)
AR|America/Argentina/Jujuy|Jujuy (JY)
AR|America/Argentina/Tucuman|Tucuman (TM)
AR|America/Argentina/Catamarca|Catamarca (CT), Chubut (CH)
AR|America/Argentina/La_Rioja|La Rioja (LR)
AR|America/Argentina/San_Juan|San Juan (SJ)
AR|America/Argentina/Mendoza|Mendoza (MZ)
AR|America/Argentina/San_Luis|San Luis (SL)
AR|America/Argentina/Rio_Gallegos|Santa Cruz (SC)
AR|America/Argentina/Ushuaia|Tierra del Fuego (TF)
AS|Pacific/Pago_Pago|
AT|Europe/Vienna|
AU|Australia/Lord_Howe|Lord Howe Island
AU|Antarctica/Macquarie|Macquarie Island
AU|Australia/Hobart|Tasmania
AU|Australia/Melbourne|Victoria
AU|Australia/Sydney|New South Wales (most areas)
AU|Australia/Broken_Hill|New South Wales (Yancowinna)
AU|Australia/Brisbane|Queensland (most areas)
AU|Australia/Lindeman|Queensland (Whitsunday Islands)
AU|Australia/Adelaide|South Australia
AU|Australia/Darwin|Northern Territory
AU|Australia/Perth|Western Australia (most areas)
AU|Australia/Eucla|Western Australia (Eucla)
AW|America/Aruba|
AX|Europe/Mariehamn|
AZ|Asia/Baku|
BA|Europe/Sarajevo|
BB|America/Barbados|
BD|Asia/Dhaka|
BE|Europe/Brussels|
BF|Africa/Ouagadougou|
BG|Europe/Sofia|
BH|Asia/Bahrain|
BI|Africa/Bujumbura|
BJ|Africa/Porto-Novo|
BL|America/St_Barthelemy|
BM|Atlantic/Bermuda|
BN|Asia/Brunei|
BO|America/La_Paz|
BQ|America/Kralendijk|
BR|America/Noronha|Atlantic islands
BR|America/Belem|Para (east), Amapa
BR|America/Fortaleza|Brazil (northeast: MA, PI, CE, RN, PB)
BR|America/Recife|Pernambuco
BR|America/Araguaina|Tocantins
BR|America/Maceio|Alagoas, Sergipe
BR|America/Bahia|Bahia
BR|America/Sao_Paulo|Brazil (southeast: GO, DF, MG, ES, RJ, SP, PR, SC, RS)
BR|America/Campo_Grande|Mato Grosso do Sul
BR|America/Cuiaba|Mato Grosso
BR|America/Santarem|Para (west)
BR|America/Porto_Velho|Rondonia
BR|America/Boa_Vista|Roraima
BR|America/Manaus|Amazonas (east)
BR|America/Eirunepe|Amazonas (west)
BR|America/Rio_Branco|Acre
BS|America/Nassau|
BT|Asia/Thimphu|
BW|Africa/Gaborone|
BY|Europe/Minsk|
BZ|America/Belize|
CA|America/St_Johns|Newfoundland, Labrador (SE)
CA|America/Halifax|Atlantic - NS (most areas), PE
CA|America/Glace_Bay|Atlantic - NS (Cape Breton)
CA|America/Moncton|Atlantic - New Brunswick
CA|America/Goose_Bay|Atlantic - Labrador (most areas)
CA|America/Blanc-Sablon|AST - QC (Lower North Shore)
CA|America/Toronto|Eastern - ON & QC (most areas)
CA|America/Iqaluit|Eastern - NU (most areas)
CA|America/Atikokan|EST - ON (Atikokan), NU (Coral H)
CA|America/Winnipeg|EST - Manitoba, ON (northwest)
CA|America/Resolute|Central - NU (Resolute)
CA|America/Rankin_Inlet|Central - NU (central)
CA|America/Regina|CST - SK (most areas)
CA|America/Swift_Current|CST - SK (midwest)
CA|America/Edmonton|CST - AB, BC(E), NT(E), SK(W)
CA|America/Cambridge_Bay|Mountain - NU (west)
CA|America/Inuvik|CST - NT (west)
CA|America/Vancouver|MST - BC (most areas)
CA|America/Creston|MST - BC (Creston)
CA|America/Dawson_Creek|MST - BC (Dawson Cr, Ft St John)
CA|America/Fort_Nelson|MST - BC (Ft Nelson)
CA|America/Whitehorse|MST - Yukon (east)
CA|America/Dawson|MST - Yukon (west)
CC|Indian/Cocos|
CD|Africa/Kinshasa|Dem. Rep. of Congo (west)
CD|Africa/Lubumbashi|Dem. Rep. of Congo (east)
CF|Africa/Bangui|
CG|Africa/Brazzaville|
CH|Europe/Zurich|
CI|Africa/Abidjan|
CK|Pacific/Rarotonga|
CL|America/Santiago|most of Chile
CL|America/Coyhaique|Aysen Region
CL|America/Punta_Arenas|Magallanes Region
CL|Pacific/Easter|Easter Island
CM|Africa/Douala|
CN|Asia/Shanghai|Beijing Time
CN|Asia/Urumqi|Xinjiang Time
CO|America/Bogota|
CR|America/Costa_Rica|
CU|America/Havana|
CV|Atlantic/Cape_Verde|
CW|America/Curacao|
CX|Indian/Christmas|
CY|Asia/Nicosia|most of Cyprus
CY|Asia/Famagusta|Northern Cyprus
CZ|Europe/Prague|
DE|Europe/Berlin|most of Germany
DE|Europe/Busingen|Busingen
DJ|Africa/Djibouti|
DK|Europe/Copenhagen|
DM|America/Dominica|
DO|America/Santo_Domingo|
DZ|Africa/Algiers|
EC|America/Guayaquil|Ecuador (mainland)
EC|Pacific/Galapagos|Galapagos Islands
EE|Europe/Tallinn|
EG|Africa/Cairo|
EH|Africa/El_Aaiun|
ER|Africa/Asmara|
ES|Europe/Madrid|Spain (mainland)
ES|Africa/Ceuta|Ceuta, Melilla
ES|Atlantic/Canary|Canary Islands
ET|Africa/Addis_Ababa|
FI|Europe/Helsinki|
FJ|Pacific/Fiji|
FK|Atlantic/Stanley|
FM|Pacific/Chuuk|Chuuk/Truk, Yap
FM|Pacific/Pohnpei|Pohnpei/Ponape
FM|Pacific/Kosrae|Kosrae
FO|Atlantic/Faroe|
FR|Europe/Paris|
GA|Africa/Libreville|
GB|Europe/London|
GD|America/Grenada|
GE|Asia/Tbilisi|
GF|America/Cayenne|
GG|Europe/Guernsey|
GH|Africa/Accra|
GI|Europe/Gibraltar|
GL|America/Nuuk|most of Greenland
GL|America/Danmarkshavn|National Park (east coast)
GL|America/Scoresbysund|Scoresbysund/Ittoqqortoormiit
GL|America/Thule|Thule/Pituffik
GM|Africa/Banjul|
GN|Africa/Conakry|
GP|America/Guadeloupe|
GQ|Africa/Malabo|
GR|Europe/Athens|
GS|Atlantic/South_Georgia|
GT|America/Guatemala|
GU|Pacific/Guam|
GW|Africa/Bissau|
GY|America/Guyana|
HK|Asia/Hong_Kong|
HN|America/Tegucigalpa|
HR|Europe/Zagreb|
HT|America/Port-au-Prince|
HU|Europe/Budapest|
ID|Asia/Jakarta|Java, Sumatra
ID|Asia/Pontianak|Borneo (west, central)
ID|Asia/Makassar|Borneo (east, south), Sulawesi/Celebes, Bali, Nusa Tengarra, Timor (west)
ID|Asia/Jayapura|New Guinea (West Papua / Irian Jaya), Malukus/Moluccas
IE|Europe/Dublin|
IL|Asia/Jerusalem|
IM|Europe/Isle_of_Man|
IN|Asia/Kolkata|
IO|Indian/Chagos|
IQ|Asia/Baghdad|
IR|Asia/Tehran|
IS|Atlantic/Reykjavik|
IT|Europe/Rome|
JE|Europe/Jersey|
JM|America/Jamaica|
JO|Asia/Amman|
JP|Asia/Tokyo|
KE|Africa/Nairobi|
KG|Asia/Bishkek|
KH|Asia/Phnom_Penh|
KI|Pacific/Tarawa|Gilbert Islands
KI|Pacific/Kanton|Phoenix Islands
KI|Pacific/Kiritimati|Line Islands
KM|Indian/Comoro|
KN|America/St_Kitts|
KP|Asia/Pyongyang|
KR|Asia/Seoul|
KW|Asia/Kuwait|
KY|America/Cayman|
KZ|Asia/Almaty|most of Kazakhstan
KZ|Asia/Qyzylorda|Qyzylorda/Kyzylorda/Kzyl-Orda
KZ|Asia/Qostanay|Qostanay/Kostanay/Kustanay
KZ|Asia/Aqtobe|Aqtobe/Aktobe
KZ|Asia/Aqtau|Mangghystau/Mankistau
KZ|Asia/Atyrau|Atyrau/Atirau/Gur'yev
KZ|Asia/Oral|West Kazakhstan
LA|Asia/Vientiane|
LB|Asia/Beirut|
LC|America/St_Lucia|
LI|Europe/Vaduz|
LK|Asia/Colombo|
LR|Africa/Monrovia|
LS|Africa/Maseru|
LT|Europe/Vilnius|
LU|Europe/Luxembourg|
LV|Europe/Riga|
LY|Africa/Tripoli|
MA|Africa/Casablanca|
MC|Europe/Monaco|
MD|Europe/Chisinau|
ME|Europe/Podgorica|
MF|America/Marigot|
MG|Indian/Antananarivo|
MH|Pacific/Majuro|most of Marshall Islands
MH|Pacific/Kwajalein|Kwajalein
MK|Europe/Skopje|
ML|Africa/Bamako|
MM|Asia/Yangon|
MN|Asia/Ulaanbaatar|most of Mongolia
MN|Asia/Hovd|Bayan-Olgii, Hovd, Uvs
MO|Asia/Macau|
MP|Pacific/Saipan|
MQ|America/Martinique|
MR|Africa/Nouakchott|
MS|America/Montserrat|
MT|Europe/Malta|
MU|Indian/Mauritius|
MV|Indian/Maldives|
MW|Africa/Blantyre|
MX|America/Mexico_City|Central Mexico
MX|America/Cancun|Quintana Roo
MX|America/Merida|Campeche, Yucatan
MX|America/Monterrey|Durango; Coahuila, Nuevo Leon, Tamaulipas (most areas)
MX|America/Matamoros|Coahuila, Nuevo Leon, Tamaulipas (US border)
MX|America/Chihuahua|Chihuahua (most areas)
MX|America/Ciudad_Juarez|Chihuahua (US border - west)
MX|America/Ojinaga|Chihuahua (US border - east)
MX|America/Mazatlan|Baja California Sur, Nayarit (most areas), Sinaloa
MX|America/Bahia_Banderas|Bahia de Banderas
MX|America/Hermosillo|Sonora
MX|America/Tijuana|Baja California
MY|Asia/Kuala_Lumpur|Malaysia (peninsula)
MY|Asia/Kuching|Sabah, Sarawak
MZ|Africa/Maputo|
NA|Africa/Windhoek|
NC|Pacific/Noumea|
NE|Africa/Niamey|
NF|Pacific/Norfolk|
NG|Africa/Lagos|
NI|America/Managua|
NL|Europe/Amsterdam|
NO|Europe/Oslo|
NP|Asia/Kathmandu|
NR|Pacific/Nauru|
NU|Pacific/Niue|
NZ|Pacific/Auckland|most of New Zealand
NZ|Pacific/Chatham|Chatham Islands
OM|Asia/Muscat|
PA|America/Panama|
PE|America/Lima|
PF|Pacific/Tahiti|Society Islands
PF|Pacific/Marquesas|Marquesas Islands
PF|Pacific/Gambier|Gambier Islands
PG|Pacific/Port_Moresby|most of Papua New Guinea
PG|Pacific/Bougainville|Bougainville
PH|Asia/Manila|
PK|Asia/Karachi|
PL|Europe/Warsaw|
PM|America/Miquelon|
PN|Pacific/Pitcairn|
PR|America/Puerto_Rico|
PS|Asia/Gaza|Gaza Strip
PS|Asia/Hebron|West Bank
PT|Europe/Lisbon|Portugal (mainland)
PT|Atlantic/Madeira|Madeira Islands
PT|Atlantic/Azores|Azores
PW|Pacific/Palau|
PY|America/Asuncion|
QA|Asia/Qatar|
RE|Indian/Reunion|
RO|Europe/Bucharest|
RS|Europe/Belgrade|
RU|Europe/Kaliningrad|MSK-01 - Kaliningrad
RU|Europe/Moscow|MSK+00 - Moscow area
UA|Europe/Simferopol|Crimea
RU|Europe/Kirov|MSK+00 - Kirov
RU|Europe/Volgograd|MSK+00 - Volgograd
RU|Europe/Astrakhan|MSK+01 - Astrakhan
RU|Europe/Saratov|MSK+01 - Saratov
RU|Europe/Ulyanovsk|MSK+01 - Ulyanovsk
RU|Europe/Samara|MSK+01 - Samara, Udmurtia
RU|Asia/Yekaterinburg|MSK+02 - Urals
RU|Asia/Omsk|MSK+03 - Omsk
RU|Asia/Novosibirsk|MSK+04 - Novosibirsk
RU|Asia/Barnaul|MSK+04 - Altai
RU|Asia/Tomsk|MSK+04 - Tomsk
RU|Asia/Novokuznetsk|MSK+04 - Kemerovo
RU|Asia/Krasnoyarsk|MSK+04 - Krasnoyarsk area
RU|Asia/Irkutsk|MSK+05 - Irkutsk, Buryatia
RU|Asia/Chita|MSK+06 - Zabaykalsky
RU|Asia/Yakutsk|MSK+06 - Lena River
RU|Asia/Khandyga|MSK+06 - Tomponsky, Ust-Maysky
RU|Asia/Vladivostok|MSK+07 - Amur River
RU|Asia/Ust-Nera|MSK+07 - Oymyakonsky
RU|Asia/Magadan|MSK+08 - Magadan
RU|Asia/Sakhalin|MSK+08 - Sakhalin Island
RU|Asia/Srednekolymsk|MSK+08 - Sakha (E), N Kuril Is
RU|Asia/Kamchatka|MSK+09 - Kamchatka
RU|Asia/Anadyr|MSK+09 - Bering Sea
RW|Africa/Kigali|
SA|Asia/Riyadh|
SB|Pacific/Guadalcanal|
SC|Indian/Mahe|
SD|Africa/Khartoum|
SE|Europe/Stockholm|
SG|Asia/Singapore|
SH|Atlantic/St_Helena|
SI|Europe/Ljubljana|
SJ|Arctic/Longyearbyen|
SK|Europe/Bratislava|
SL|Africa/Freetown|
SM|Europe/San_Marino|
SN|Africa/Dakar|
SO|Africa/Mogadishu|
SR|America/Paramaribo|
SS|Africa/Juba|
ST|Africa/Sao_Tome|
SV|America/El_Salvador|
SX|America/Lower_Princes|
SY|Asia/Damascus|
SZ|Africa/Mbabane|
TC|America/Grand_Turk|
TD|Africa/Ndjamena|
TF|Indian/Kerguelen|
TG|Africa/Lome|
TH|Asia/Bangkok|
TJ|Asia/Dushanbe|
TK|Pacific/Fakaofo|
TL|Asia/Dili|
TM|Asia/Ashgabat|
TN|Africa/Tunis|
TO|Pacific/Tongatapu|
TR|Europe/Istanbul|
TT|America/Port_of_Spain|
TV|Pacific/Funafuti|
TW|Asia/Taipei|
TZ|Africa/Dar_es_Salaam|
UA|Europe/Kyiv|most of Ukraine
UG|Africa/Kampala|
UM|Pacific/Midway|Midway Islands
UM|Pacific/Wake|Wake Island
US|America/New_York|Eastern (most areas)
US|America/Detroit|Eastern - MI (most areas)
US|America/Kentucky/Louisville|Eastern - KY (Louisville area)
US|America/Kentucky/Monticello|Eastern - KY (Wayne)
US|America/Indiana/Indianapolis|Eastern - IN (most areas)
US|America/Indiana/Vincennes|Eastern - IN (Da, Du, K, Mn)
US|America/Indiana/Winamac|Eastern - IN (Pulaski)
US|America/Indiana/Marengo|Eastern - IN (Crawford)
US|America/Indiana/Petersburg|Eastern - IN (Pike)
US|America/Indiana/Vevay|Eastern - IN (Switzerland)
US|America/Chicago|Central (most areas)
US|America/Indiana/Tell_City|Central - IN (Perry)
US|America/Indiana/Knox|Central - IN (Starke)
US|America/Menominee|Central - MI (Wisconsin border)
US|America/North_Dakota/Center|Central - ND (Oliver)
US|America/North_Dakota/New_Salem|Central - ND (Morton rural)
US|America/North_Dakota/Beulah|Central - ND (Mercer)
US|America/Denver|Mountain (most areas)
US|America/Boise|Mountain - ID (south), OR (east)
US|America/Phoenix|MST - AZ (except Navajo)
US|America/Los_Angeles|Pacific
US|America/Anchorage|Alaska (most areas)
US|America/Juneau|Alaska - Juneau area
US|America/Sitka|Alaska - Sitka area
US|America/Metlakatla|Alaska - Annette Island
US|America/Yakutat|Alaska - Yakutat
US|America/Nome|Alaska (west)
US|America/Adak|Alaska - western Aleutians
US|Pacific/Honolulu|Hawaii
UY|America/Montevideo|
UZ|Asia/Samarkand|Uzbekistan (west)
UZ|Asia/Tashkent|Uzbekistan (east)
VA|Europe/Vatican|
VC|America/St_Vincent|
VE|America/Caracas|
VG|America/Tortola|
VI|America/St_Thomas|
VN|Asia/Ho_Chi_Minh|
VU|Pacific/Efate|
WF|Pacific/Wallis|
WS|Pacific/Apia|
YE|Asia/Aden|
YT|Indian/Mayotte|
ZA|Africa/Johannesburg|
ZM|Africa/Lusaka|
ZW|Africa/Harare|`,xe=`Australia/ACT|Australia/Sydney
Australia/LHI|Australia/Lord_Howe
Australia/NSW|Australia/Sydney
Australia/North|Australia/Darwin
Australia/Queensland|Australia/Brisbane
Australia/South|Australia/Adelaide
Australia/Tasmania|Australia/Hobart
Australia/Victoria|Australia/Melbourne
Australia/West|Australia/Perth
Australia/Yancowinna|Australia/Broken_Hill
Brazil/Acre|America/Rio_Branco
Brazil/DeNoronha|America/Noronha
Brazil/East|America/Sao_Paulo
Brazil/West|America/Manaus
Canada/Atlantic|America/Halifax
Canada/Central|America/Winnipeg
Canada/Eastern|America/Toronto
Canada/Mountain|America/Edmonton
Canada/Newfoundland|America/St_Johns
Canada/Pacific|America/Vancouver
Canada/Saskatchewan|America/Regina
Canada/Yukon|America/Whitehorse
Chile/Continental|America/Santiago
Chile/EasterIsland|Pacific/Easter
Mexico/BajaNorte|America/Tijuana
Mexico/BajaSur|America/Mazatlan
Mexico/General|America/Mexico_City
US/Alaska|America/Anchorage
US/Aleutian|America/Adak
US/Arizona|America/Phoenix
US/Central|America/Chicago
US/East-Indiana|America/Indiana/Indianapolis
US/Eastern|America/New_York
US/Hawaii|Pacific/Honolulu
US/Indiana-Starke|America/Indiana/Knox
US/Michigan|America/Detroit
US/Mountain|America/Denver
US/Pacific|America/Los_Angeles
US/Samoa|Pacific/Pago_Pago
America/Buenos_Aires|America/Argentina/Buenos_Aires
America/Catamarca|America/Argentina/Catamarca
America/Cordoba|America/Argentina/Cordoba
America/Indianapolis|America/Indiana/Indianapolis
America/Jujuy|America/Argentina/Jujuy
America/Knox_IN|America/Indiana/Knox
America/Louisville|America/Kentucky/Louisville
America/Mendoza|America/Argentina/Mendoza
America/Virgin|America/Puerto_Rico
Pacific/Samoa|Pacific/Pago_Pago
Africa/Accra|Africa/Abidjan
Africa/Addis_Ababa|Africa/Nairobi
Africa/Asmara|Africa/Nairobi
Africa/Bamako|Africa/Abidjan
Africa/Bangui|Africa/Lagos
Africa/Banjul|Africa/Abidjan
Africa/Blantyre|Africa/Maputo
Africa/Brazzaville|Africa/Lagos
Africa/Bujumbura|Africa/Maputo
Africa/Conakry|Africa/Abidjan
Africa/Dakar|Africa/Abidjan
Africa/Dar_es_Salaam|Africa/Nairobi
Africa/Djibouti|Africa/Nairobi
Africa/Douala|Africa/Lagos
Africa/Freetown|Africa/Abidjan
Africa/Gaborone|Africa/Maputo
Africa/Harare|Africa/Maputo
Africa/Kampala|Africa/Nairobi
Africa/Kigali|Africa/Maputo
Africa/Kinshasa|Africa/Lagos
Africa/Libreville|Africa/Lagos
Africa/Lome|Africa/Abidjan
Africa/Luanda|Africa/Lagos
Africa/Lubumbashi|Africa/Maputo
Africa/Lusaka|Africa/Maputo
Africa/Malabo|Africa/Lagos
Africa/Maseru|Africa/Johannesburg
Africa/Mbabane|Africa/Johannesburg
Africa/Mogadishu|Africa/Nairobi
Africa/Niamey|Africa/Lagos
Africa/Nouakchott|Africa/Abidjan
Africa/Ouagadougou|Africa/Abidjan
Africa/Porto-Novo|Africa/Lagos
America/Anguilla|America/Puerto_Rico
America/Antigua|America/Puerto_Rico
America/Aruba|America/Puerto_Rico
America/Atikokan|America/Panama
America/Blanc-Sablon|America/Puerto_Rico
America/Cayman|America/Panama
America/Creston|America/Phoenix
America/Curacao|America/Puerto_Rico
America/Dominica|America/Puerto_Rico
America/Grenada|America/Puerto_Rico
America/Guadeloupe|America/Puerto_Rico
America/Kralendijk|America/Puerto_Rico
America/Lower_Princes|America/Puerto_Rico
America/Marigot|America/Puerto_Rico
America/Montserrat|America/Puerto_Rico
America/Nassau|America/Toronto
America/Port_of_Spain|America/Puerto_Rico
America/St_Barthelemy|America/Puerto_Rico
America/St_Kitts|America/Puerto_Rico
America/St_Lucia|America/Puerto_Rico
America/St_Thomas|America/Puerto_Rico
America/St_Vincent|America/Puerto_Rico
America/Tortola|America/Puerto_Rico
Antarctica/DumontDUrville|Pacific/Port_Moresby
Antarctica/McMurdo|Pacific/Auckland
Antarctica/Syowa|Asia/Riyadh
Arctic/Longyearbyen|Europe/Berlin
Asia/Aden|Asia/Riyadh
Asia/Bahrain|Asia/Qatar
Asia/Brunei|Asia/Kuching
Asia/Kuala_Lumpur|Asia/Singapore
Asia/Kuwait|Asia/Riyadh
Asia/Muscat|Asia/Dubai
Asia/Phnom_Penh|Asia/Bangkok
Asia/Vientiane|Asia/Bangkok
Atlantic/Reykjavik|Africa/Abidjan
Atlantic/St_Helena|Africa/Abidjan
Europe/Amsterdam|Europe/Brussels
Europe/Bratislava|Europe/Prague
Europe/Busingen|Europe/Zurich
Europe/Copenhagen|Europe/Berlin
Europe/Guernsey|Europe/London
Europe/Isle_of_Man|Europe/London
Europe/Jersey|Europe/London
Europe/Ljubljana|Europe/Belgrade
Europe/Luxembourg|Europe/Brussels
Europe/Mariehamn|Europe/Helsinki
Europe/Monaco|Europe/Paris
Europe/Oslo|Europe/Berlin
Europe/Podgorica|Europe/Belgrade
Europe/San_Marino|Europe/Rome
Europe/Sarajevo|Europe/Belgrade
Europe/Skopje|Europe/Belgrade
Europe/Stockholm|Europe/Berlin
Europe/Vaduz|Europe/Zurich
Europe/Vatican|Europe/Rome
Europe/Zagreb|Europe/Belgrade
Indian/Antananarivo|Africa/Nairobi
Indian/Christmas|Asia/Bangkok
Indian/Cocos|Asia/Yangon
Indian/Comoro|Africa/Nairobi
Indian/Kerguelen|Indian/Maldives
Indian/Mahe|Asia/Dubai
Indian/Mayotte|Africa/Nairobi
Indian/Reunion|Asia/Dubai
Pacific/Chuuk|Pacific/Port_Moresby
Pacific/Funafuti|Pacific/Tarawa
Pacific/Majuro|Pacific/Tarawa
Pacific/Midway|Pacific/Pago_Pago
Pacific/Pohnpei|Pacific/Guadalcanal
Pacific/Saipan|Pacific/Guam
Pacific/Wake|Pacific/Tarawa
Pacific/Wallis|Pacific/Tarawa
Africa/Timbuktu|Africa/Abidjan
America/Argentina/ComodRivadavia|America/Argentina/Catamarca
America/Atka|America/Adak
America/Coral_Harbour|America/Panama
America/Ensenada|America/Tijuana
America/Fort_Wayne|America/Indiana/Indianapolis
America/Montreal|America/Toronto
America/Nipigon|America/Toronto
America/Pangnirtung|America/Iqaluit
America/Porto_Acre|America/Rio_Branco
America/Rainy_River|America/Winnipeg
America/Rosario|America/Argentina/Cordoba
America/Santa_Isabel|America/Tijuana
America/Shiprock|America/Denver
America/Thunder_Bay|America/Toronto
America/Yellowknife|America/Edmonton
Antarctica/South_Pole|Pacific/Auckland
Asia/Choibalsan|Asia/Ulaanbaatar
Asia/Chongqing|Asia/Shanghai
Asia/Harbin|Asia/Shanghai
Asia/Kashgar|Asia/Urumqi
Asia/Tel_Aviv|Asia/Jerusalem
Atlantic/Jan_Mayen|Europe/Berlin
Australia/Canberra|Australia/Sydney
Australia/Currie|Australia/Hobart
Europe/Belfast|Europe/London
Europe/Tiraspol|Europe/Chisinau
Europe/Uzhgorod|Europe/Kyiv
Europe/Zaporozhye|Europe/Kyiv
Pacific/Enderbury|Pacific/Kanton
Pacific/Johnston|Pacific/Honolulu
Pacific/Yap|Pacific/Port_Moresby
Africa/Asmera|Africa/Nairobi
America/Godthab|America/Nuuk
Asia/Ashkhabad|Asia/Ashgabat
Asia/Calcutta|Asia/Kolkata
Asia/Chungking|Asia/Shanghai
Asia/Dacca|Asia/Dhaka
Asia/Istanbul|Europe/Istanbul
Asia/Katmandu|Asia/Kathmandu
Asia/Macao|Asia/Macau
Asia/Rangoon|Asia/Yangon
Asia/Saigon|Asia/Ho_Chi_Minh
Asia/Thimbu|Asia/Thimphu
Asia/Ujung_Pandang|Asia/Makassar
Asia/Ulan_Bator|Asia/Ulaanbaatar
Atlantic/Faeroe|Atlantic/Faroe
Europe/Kiev|Europe/Kyiv
Europe/Nicosia|Asia/Nicosia
Pacific/Ponape|Pacific/Guadalcanal
Pacific/Truk|Pacific/Port_Moresby`,Se=`Pacific/Honolulu.America/Anchorage.America/Los_Angeles.America/Vancouver.America/Tijuana.America/Phoenix.America/Denver.America/Edmonton.America/Chicago.America/Mexico_City.America/Winnipeg.America/New_York.America/Toronto.America/Detroit.America/Panama.America/Bogota.America/Lima.America/Caracas.America/Halifax.America/Puerto_Rico.America/Santiago.America/St_Johns.America/Sao_Paulo.America/Recife.America/Argentina/Buenos_Aires.America/Montevideo.Atlantic/Azores.Atlantic/Reykjavik.Europe/London.Europe/Dublin.Europe/Lisbon.Africa/Casablanca.Africa/Lagos.Europe/Paris.Europe/Brussels.Europe/Amsterdam.Europe/Berlin.Europe/Zurich.Europe/Vienna.Europe/Rome.Europe/Madrid.Europe/Stockholm.Europe/Oslo.Europe/Copenhagen.Europe/Prague.Europe/Warsaw.Europe/Budapest.Europe/Belgrade.Africa/Johannesburg.Africa/Cairo.Europe/Athens.Europe/Bucharest.Europe/Helsinki.Europe/Kyiv.Asia/Jerusalem.Europe/Istanbul.Europe/Moscow.Africa/Nairobi.Asia/Riyadh.Asia/Baghdad.Asia/Tehran.Asia/Dubai.Asia/Baku.Asia/Kabul.Asia/Karachi.Asia/Tashkent.Asia/Kolkata.Asia/Colombo.Asia/Kathmandu.Asia/Dhaka.Asia/Almaty.Asia/Yangon.Asia/Bangkok.Asia/Ho_Chi_Minh.Asia/Jakarta.Asia/Singapore.Asia/Kuala_Lumpur.Asia/Manila.Asia/Shanghai.Asia/Hong_Kong.Asia/Taipei.Australia/Perth.Asia/Seoul.Asia/Tokyo.Australia/Darwin.Australia/Adelaide.Australia/Brisbane.Australia/Sydney.Australia/Melbourne.Australia/Hobart.Pacific/Guam.Pacific/Noumea.Pacific/Auckland.Pacific/Fiji.Pacific/Tongatapu.Pacific/Kiritimati.UTC`.split(`.`),Ce=`-12:00.-11:00.-10:00.-09:30.-09:00.-08:00.-07:00.-06:00.-05:00.-04:00.-03:30.-03:00.-02:00.-01:00.+00:00.+01:00.+02:00.+03:00.+03:30.+04:00.+04:30.+05:00.+05:30.+05:45.+06:00.+06:30.+07:00.+08:00.+08:45.+09:00.+09:30.+10:00.+10:30.+11:00.+12:00.+12:45.+13:00.+14:00`.split(`.`),we=/^(?:UTC|GMT)?\s*([+-])(\d{1,2})(?::?(\d{2}))?$/i;function C(e){var t=we.exec(e.trim());if(t){var n=Number(t[2]),r=Number(t[3]??0);if(!(n>14||r>59))return`${t[1]}${String(n).padStart(2,`0`)}:${String(r).padStart(2,`0`)}`}}function w(e){var t=C(e);if(t)return(t[0]===`-`?-1:1)*(Number(t.slice(1,3))*60+Number(t.slice(4,6)))}var Te=new Map;function Ee(e){if(Te.has(e))return Te.get(e)??void 0;var t=null;try{t=new Intl.DateTimeFormat(`en-US`,{timeZone:e,year:`numeric`,month:`2-digit`,day:`2-digit`,hour:`2-digit`,minute:`2-digit`,hour12:!1})}catch{}return Te.set(e,t),t??void 0}function T(e,t){var n=w(e);if(n!==void 0)return n;var r=Ee(e);if(r)try{var i=r.format(new Date(t)).match(/\d+/g);if(!i||i.length<5)return;var[a,o,s,c,l]=i.map(Number),u=Date.UTC(s,a-1,o,c%24,l),d=Math.floor(t/6e4)*6e4;return Math.round((u-d)/6e4)}catch{return}}var E;function D(){if(E!==void 0)return E;var e=Date.now();return E=T(`Asia/Tokyo`,e)===540&&T(`UTC`,e)===0,E}function De(e){return w(e)!==void 0||D()&&T(e,Date.now())!==void 0}function O(e){if(e===0)return`UTC`;var t=e<0?`−`:`+`,n=Math.abs(e),r=n%60;return`UTC${t}${Math.floor(n/60)}${r?`:${String(r).padStart(2,`0`)}`:``}`}var Oe=[`Sun`,`Mon`,`Tue`,`Wed`,`Thu`,`Fri`,`Sat`];function ke(e,t,n){var r=String(t).padStart(2,`0`);return n?`${String(e).padStart(2,`0`)}:${r}`:`${e%12||12}:${r} ${e>=12?`PM`:`AM`}`}function k(e,t,n){if(Number.isFinite(t)&&(w(e)!==void 0||D())){var r=T(e,t);if(r!==void 0){var i=new Date(t+r*6e4),a=new Date(t),o=i.getUTCDay();return{time:ke(i.getUTCHours(),i.getUTCMinutes(),n),otherDay:o===a.getDay()?void 0:Oe[o],offset:O(r)}}}}function A(e){var t=w(e);return t===void 0?(e.split(`/`).pop()??e).replace(/_/g,` `):O(t)}function Ae(e){if(typeof e==`string`){var t=e.trim();if(t)return C(t)??t}}var je={usa:`US`,us:`US`,america:`US`,"united states of america":`US`,uk:`GB`,"united kingdom":`GB`,"great britain":`GB`,britain:`GB`,england:`GB`,scotland:`GB`,wales:`GB`,"northern ireland":`GB`,uae:`AE`,emirates:`AE`,"united arab emirates":`AE`,"south korea":`KR`,korea:`KR`,"north korea":`KP`,holland:`NL`,czechia:`CZ`,turkiye:`TR`,burma:`MM`,"ivory coast":`CI`,drc:`CD`,"democratic republic of the congo":`CD`,"republic of the congo":`CG`,swaziland:`SZ`,macao:`MO`,"cape verde":`CV`,"east timor":`TL`,palestine:`PS`,vatican:`VA`,"american samoa":`AS`,samoa:`WS`,bosnia:`BA`,trinidad:`TT`},Me=RegExp(`[̀-ͯ]`,`g`);function j(e){var t=e.toLowerCase();try{t=t.normalize(`NFD`).replace(Me,``)}catch{}return t.replace(/[_\-/().,'&]+/g,` `).replace(/\s+/g,` `).trim()}var M;function N(){if(M)return M;var e=[],t=new Map;for(var n of be.split(`
`)){var[r,i,a=``]=n.split(`|`);if(i){var o=A(i),s={zone:i,cc:r,country:S[r]??r,city:o,note:a,cityKey:j(o),pathKey:j(i),noteKey:j(a)};e.push(s);var c=t.get(r)??[];c.push(s),t.set(r,c)}}var l=[];for(var u of xe.split(`
`)){var[d,f]=u.split(`|`);d&&f&&l.push([j(d),d,f])}return M={zones:e,byCountry:t,links:l},M}function Ne(e){var t=[],n=[],r=je[e];r&&t.push(r);for(var[i,a]of Object.entries(je))i!==e&&i.startsWith(e)&&e.length>=3&&!t.includes(a)&&t.push(a);for(var o of Object.keys(S)){var s=j(S[o]);t.includes(o)||(s===e||s.startsWith(e)?t.push(o):e.length>=3&&s.includes(e)&&n.push(o))}return[...t,...n]}function P(e){return{zone:e.zone,title:e.city,detail:e.note?`${e.country} · ${e.note}`:e.country,place:`${e.city}, ${e.country}`}}function Pe(e){var t=S[e]??e,n=N().byCountry.get(e)??[];return n.length===1?[{zone:n[0].zone,title:t,detail:n[0].city,place:t}]:n.map(function(e){return{zone:e.zone,title:`${t} — ${e.city}`,detail:e.note||void 0,place:`${e.city}, ${t}`}})}function F(e){var t=w(e);if(t!==void 0)return{zone:e,title:O(t),detail:`Fixed offset, no daylight saving`};var n=N().zones.find(function(t){return t.zone===e});return n?P(n):{zone:e,title:A(e)}}function Fe(e,t=60){var n=j(e);if(!n)return Se.map(F).slice(0,t);var{zones:r,links:i}=N(),a=[],o=new Set,s=function(e){o.has(e.zone)||(o.add(e.zone),a.push(e))},c=C(e);c&&s(F(c)),(n===`utc`||n===`gmt`)&&s(F(`UTC`));for(var l of Ne(n))for(var u of Pe(l))s(u);for(var d of r)d.cityKey.startsWith(n)&&s(P(d));var f=new Set(r.map(function(e){return e.zone}));for(var[p,m,h]of i)f.has(m)||((p.split(` `).pop()??p).startsWith(n)||p===n)&&s({...F(h),detail:`Old name: ${m}`});if(n.length>=3){for(var g of r)(g.cityKey.includes(n)||g.pathKey.includes(n))&&s(P(g));for(var _ of r)_.noteKey.includes(n)&&s(P(_))}var v=e.trim();/^[A-Za-z]/.test(v)&&v.length>=3&&!o.has(v)&&De(v)&&s({zone:v,title:v});var y=v.replace(/^(?:utc|gmt)\s*/i,``);if(/^[+-]\d/.test(y))for(var b of Ce)(b.startsWith(y)||b.replace(/^([+-])0/,`$1`).startsWith(y))&&s(F(b));return a.slice(0,t)}var Ie=`[Timezones]`,Le=`https://timezonedb.catvibers.me/api/user/bulk`,Re=100,ze=300,Be=36e5,Ve=1e4,He=new Map,I=new Set,Ue=new Set,L=new Set,R,z=!1;function We(e){var t=He.get(e);if(t&&!(Date.now()-t.at>Be))return t.zone??null}function Ge(e){!z&&/^\d{15,21}$/.test(e)&&(We(e)!==void 0||Ue.has(e)||I.has(e)||(I.add(e),R===void 0&&(R=setTimeout(Ye,ze))))}function Ke(e){He.delete(e),Ge(e)}function qe(e){return L.add(e),function(){return L.delete(e)}}function Je(){for(var e of L)try{e()}catch{}}async function Ye(){if(R=void 0,!z&&I.size){var e=[...I].slice(0,Re);for(var t of e)I.delete(t),Ue.add(t);I.size&&(R=setTimeout(Ye,ze));var n=typeof AbortController==`function`?new AbortController:void 0,r=setTimeout(function(){return n?.abort()},Ve);try{var i=await fetch(Le,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(e),signal:n?.signal});if(!i.ok)throw Error(`HTTP ${i.status}`);var a=await i.json(),o=Date.now();for(var s of e){var c=a?.[s];He.set(s,{zone:Ae(c?.timezone),at:o})}z||Je()}catch(e){m(`${Ie} shared timezone lookup failed:`,e)}finally{clearTimeout(r);for(var l of e)Ue.delete(l)}}}function Xe(){z=!1}function Ze(){z=!0,R!==void 0&&clearTimeout(R),R=void 0,I.clear(),L.clear()}var B={showInChat:!0,sharedLookup:!0,placeSearch:!0,hour24:!1,showDay:!0,people:{}},V,H,U=!1,W={...B},Qe=new Set;function $e(){for(var e of Qe)try{e()}catch{}}function et(e){var t={};if(!e||typeof e!=`object`)return t;for(var n of Object.keys(e)){var r=e[n];r&&typeof r.zone==`string`&&(t[n]=r)}return t}function G(e,t){var n={...e,...t??{}};return n.people=et(t?.people&&typeof t.people==`object`?{...e.people,...t.people}:e.people),n}function tt(e){if(!(e&&e===V)&&(H?.(),H=void 0,V=e,U=!1,W={...B},e)){var t=e.cache;t&&(W=G(B,t),U=!0),H=e.subscribe?.(function(e,t){W=G(t===0?W:B,e),U=!0,$e()}),Promise.resolve(e.get?.()).then(function(e){e&&(W=G(B,e)),U=!0,$e()}).catch(function(){})}}function nt(e){!V&&e&&tt(e)}function K(){return W}function q(){var[,e]=revenge.react.React.useReducer(function(e){return e+1},0);return revenge.react.React.useEffect(function(){return it(e)},[]),W}function J(e){W={...G(W,e),...e.people?{people:et(e.people)}:{}},$e();try{var t=U?V?.set?.(W,!0):V?.set(e);Promise.resolve(t).catch(function(){})}catch{}}function rt(e,t,n,r){var i={...K().people};n?i[e]={zone:n,name:t,at:Date.now(),...r?{place:r}:{}}:delete i[e],J({people:i})}function it(e){return Qe.add(e),function(){return Qe.delete(e)}}function at(e){var t=K(),n=t.people[e];if(n?.zone)return{zone:n.zone,place:n.place,source:`you`};if(t.sharedLookup){var r=We(e);if(r)return{zone:r,source:`shared`};r===void 0&&Ge(e)}}var Y=`[Timezones]`,ot=` · `;function st(e){try{if(e==null)return;if(typeof e==`number`)return e;if(e instanceof Date)return e.getTime();if(typeof e==`string`)return Date.parse(e);if(typeof e.valueOf==`function`){var t=Number(e.valueOf());if(Number.isFinite(t))return t}}catch{}}function ct(){try{return revenge.discord.flux.Stores.UserStore?.getCurrentUser?.()?.id}catch{return}}function lt(e,t){var n=K();if(n.showInChat&&t!==void 0&&e!==ct()){var r=at(e);if(r){var i=k(r.zone,t,n.hour24);if(i)return`${ot}${i.time}${n.showDay&&i.otherDay?` ${i.otherDay}`:``}`}}}function ut(e,t){if(typeof e!=`string`||!e||e.endsWith(t))return e;var n=e.indexOf(ot);return`${n>0?e.slice(0,n):e}${t}`}var dt=200,X=new Map;function ft(e,t){X.delete(e),X.set(e,t),X.size>dt&&X.delete(X.keys().next().value)}var Z;function pt(){Z===void 0&&(Z=setTimeout(function(){Z=void 0;for(var[e,t]of[...X])try{if(lt(t.authorId,t.at)===t.shown)continue;var n=e.indexOf(`:`);n>0&&ye(e.slice(0,n),e.slice(n+1))}catch(e){m(`${Y} refresh failed:`,e)}},50))}function mt(){var{getModules:e}=revenge.modules.finders,{withName:t}=revenge.modules.finders.filters,n=[],r,i=e(t(`RowManager`),function(e){try{if(typeof e?.prototype?.generate!=`function`){m(`${Y} RowManager.prototype.generate not found`,Error(`missing`));return}n.push(revenge.patcher.before(e.prototype,`generate`,function(e){return r=e?.[0],e})),n.push(revenge.patcher.after(e.prototype,`generate`,function(e){var t=r;r=void 0;try{if(t?.rowType!==1)return e;var n=t.message,i=n?.author?.id==null?void 0:String(n.author.id);if(!i||!n?.id||!n?.channel_id)return e;var a=st(n.timestamp),o=lt(i,a);if(ft(`${n.channel_id}:${n.id}`,{authorId:i,at:a,shown:o}),!o)return e;var s=e?.message;s&&s.state===`SENT`&&typeof s.timestamp==`string`&&(s.timestamp=ut(s.timestamp,o)),typeof n.__customTimestamp==`string`&&(n.__customTimestamp=ut(n.__customTimestamp,o))}catch(e){m(`${Y} chat timestamp failed:`,e)}return e}))}catch(e){m(`${Y} could not patch RowManager:`,e)}}),a=qe(function(){return pt()}),o=it(function(){return pt()});return function(){a(),o(),i();for(var e of n.reverse())e();r=void 0,Z!==void 0&&clearTimeout(Z),Z=void 0,X.clear()}}function ht(e,t,n){if(t&&n){var r=function(e,i,a){if(!(!e||a>40)){if(Array.isArray(e)){for(var o of e){var s=r(o,i,a+1);if(s)return s}return}if(e.props){var c=i||e.type===t,l=e.props.children;return c&&(Array.isArray(l)?l:[l]).some(function(e){return e?.type===n})?e:r(l,c,a+1)}}};return r(e,!1,0)}}var gt=`https://geocoding-api.open-meteo.com/v1/search`,_t=8e3,vt=10,yt=new Map;async function bt(e){var t=e.trim(),n=t.toLowerCase(),r=yt.get(n);if(r)return r;var i=typeof AbortController==`function`?new AbortController:void 0,a=setTimeout(function(){return i?.abort()},_t);try{var o=function(e){if(typeof e?.timezone!=`string`||typeof e?.name!=`string`)return`continue`;var t=[e.admin1,e.country].filter(function(t){return typeof t==`string`&&t&&t!==e.name});u.push({zone:e.timezone,title:e.name,detail:t.join(`, `)||void 0,place:e.country&&e.country!==e.name?`${e.name}, ${e.country}`:e.name})},s=`${gt}?name=${encodeURIComponent(t)}&count=${vt}&language=en&format=json`,c=await fetch(s,{signal:i?.signal});if(!c.ok)throw Error(`HTTP ${c.status}`);var l=await c.json(),u=[];for(var d of Array.isArray(l?.results)?l.results:[])o(d);return yt.set(n,u),u}finally{clearTimeout(a)}}function xt(e,t=`SharedToast`){try{var n=revenge.discord.actions.ToastActionCreators,r={text:e};if(typeof n.openMana==`function`){n.openMana(t,r);return}n.open(t,r)}catch{}}var St=`[Timezones]`,Ct=`TimezonesPicker`;function wt(e){var t=k(e,Date.now(),K().hour24);return t?`${t.time}${t.otherDay?` ${t.otherDay}`:``} now · ${t.offset}`:`This phone can't show this zone`}var Tt=450;function Et(e){var[t,n]=revenge.react.React.useState(),r=e.trim(),i=K().placeSearch&&r.length>=2&&!/^[+-]?\d/.test(r)&&!r.includes(`/`);return revenge.react.React.useEffect(function(){if(i){var e=!0,t=setTimeout(function(){bt(r).then(function(t){return e&&n({q:r,places:t,failed:!1})},function(){return e&&n({q:r,places:[],failed:!0})})},Tt);return function(){e=!1,clearTimeout(t)}}},[r,i]),i?t?.q===r?{places:t.places,state:t.failed?`failed`:`done`}:{places:[],state:`loading`}:{places:[],state:`idle`}}function Dt({current:e,onPick:n}){var{TextInput:r,TableRowGroup:i,TableRow:a}=revenge.discord.design.Design,{ScrollView:o,View:s}=revenge.react.ReactNative,[c,l]=revenge.react.React.useState(``),u=Fe(c),d=Et(c),f=d.places.filter(function(e){return!u.some(function(t){return t.zone===e.zone&&t.title===e.title})}),p=function(r,i){return(0,t.jsx)(a,{label:r.zone===e?`${r.title} ✓`:r.title,subLabel:[r.detail,wt(r.zone)].filter(Boolean).join(` · `),onPress:function(){return n(r)}},`${r.zone}|${r.title}|${i}`)},m=d.state===`loading`?`Searching places…`:d.state===`failed`?`Couldn't search places online.`:d.state===`done`&&f.length===0&&u.length===0?`No place by that name.`:void 0;return(0,t.jsxs)(s,{style:{gap:12},children:[(0,t.jsx)(r,{placeholder:`A country, city or town, or an offset like +5:30`,autoCapitalize:`none`,autoCorrect:!1,value:c,onChange:l}),(0,t.jsx)(o,{style:{maxHeight:320},keyboardShouldPersistTaps:`handled`,nestedScrollEnabled:!0,children:(0,t.jsxs)(s,{style:{gap:12},children:[u.length>0&&(0,t.jsx)(i,{title:c.trim()?`Countries and zones`:void 0,children:u.map(p)}),(f.length>0||m)&&(0,t.jsxs)(i,{title:`Places`,children:[f.map(p),m&&(0,t.jsx)(a,{label:m})]}),u.length===0&&d.state===`idle`&&(0,t.jsx)(i,{children:(0,t.jsx)(a,{label:`No matching timezone`,subLabel:`Try their country, a big city near them, or an offset like -4.`})})]})})]})}function Ot(e,n){var{AlertModal:r,AlertActionButton:i}=revenge.discord.design.Design,a=revenge.discord.actions.AlertActionCreators,o=K().people[e],s=o?.zone,c=at(e),l=function(t,r){a.dismissAlert(Ct);try{rt(e,n,t,r),xt(t?`${n}: ${r??A(t)}`:`Timezone for ${n} cleared.`,`TimezonesSavedToast`)}catch(e){m(`${St} saving the timezone failed:`,e)}},u=s?`Set to ${o?.place?`${o.place} (${s})`:s}. Pick another, or clear it.`:c?`The shared list says ${c.zone}. Picking one here overrides it for you.`:`Their local time shows next to their messages. Only you see this.`;a.openAlert(Ct,(0,t.jsx)(r,{title:`Timezone for ${n}`,content:u,extraContent:(0,t.jsx)(Dt,{current:s??c?.zone,onPick:function(e){return l(e.zone,e.place)}}),actions:(0,t.jsxs)(t.Fragment,{children:[s&&(0,t.jsx)(i,{text:`Clear`,variant:`destructive`,onPress:function(){return l(void 0)}}),(0,t.jsx)(i,{text:`Cancel`,variant:`secondary`,onPress:function(){return a.dismissAlert(Ct)}})]})}))}var kt=`[Timezones]`;function At(e){return/message/i.test(e)&&!/channel|forum|guild|thread/i.test(e)}var jt;function Mt(){if(!jt){var{lookupModule:e}=revenge.modules.finders,{withProps:t}=revenge.modules.finders.filters;jt=e(t(`ActionSheetRow`))?.[0]?.ActionSheetRow}return jt}function Nt(e){var t=new Set,n,r=function(e,i){if(!(n||!e||i>30||t.has(e))){if(t.add(e),e.props?.message?.author){n=e.props.message;return}if(Array.isArray(e))for(var a of e)r(a,i+1);else r(e.props?.children,i+1)}};return r(e,0),n}function Pt(e){var n=Mt();if(!n)return null;var r=e?.author?.id==null?``:String(e.author.id);if(!r)return null;try{if(r===revenge.discord.flux.Stores.UserStore?.getCurrentUser?.()?.id)return null}catch{}var i=e.author?.globalName??e.author?.username??`this person`,a=at(r),o=a&&k(a.zone,Date.now(),K().hour24),s=o?`Their time: ${o.time}${o.otherDay?` ${o.otherDay}`:``}`:`Set their timezone…`,c=a?`${a.place??A(a.zone)} · ${a.source===`you`?`set by you, tap to change`:`from the shared list, tap to set your own`}`:`Show their local time next to their messages`,{getAssetIdByName:l}=revenge.assets;return(0,t.jsx)(n.Group,{children:(0,t.jsx)(n,{label:s,subLabel:c,icon:(0,t.jsx)(n.Icon,{source:l(`ClockIcon`)}),onPress:function(){try{revenge.discord.actions.ActionSheetActionCreators.hideActionSheet()}catch{}Ot(r,i)}})})}function Ft(e,t){if(!t)return!1;var n=Pt(t);if(!n)return!1;var{ActionSheet:r}=revenge.discord.design.Design,i=ht(e,r,Mt()?.Group);if(!i)return!1;var a=i.props.children;return Array.isArray(a)?a.unshift(n):i.props.children=[n,a],!0}var It=new WeakSet;function Lt(e,t){if(!e||typeof e.default!=`function`||It.has(e))return e;var n;return t.push(revenge.patcher.before(e,`default`,function(e){return n=e?.[0]?.message,e})),t.push(revenge.patcher.after(e,`default`,function(e){try{e!=null&&Ft(e,n?.author?n:Nt(e))}catch(e){m(`${kt} sheet injection failed:`,e)}return n=void 0,e})),It.add(e),e}function Rt(){var{ActionSheetActionCreators:e}=revenge.discord.actions,t=[];return t.push(revenge.patcher.before(e,`openLazy`,function(e){try{var[n,r]=e;typeof r==`string`&&At(r)&&n&&typeof n.then==`function`&&(e[0]=n.then(function(e){return Lt(e,t)}))}catch(e){m(`${kt} openLazy hook failed:`,e)}return e})),function(){for(var e of t)try{e()}catch{}}}function zt(e){var{AlertModal:n,AlertActionButton:r}=revenge.discord.design.Design,i=revenge.discord.actions.AlertActionCreators,a=`bleelblep-confirm-${Date.now()}`;i.openAlert(a,(0,t.jsx)(n,{title:e.title,content:e.body,actions:(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(r,{text:e.action,variant:`destructive`,onPress:function(){i.dismissAlert(a),e.onConfirm()}}),(0,t.jsx)(r,{text:`Cancel`,variant:`secondary`,onPress:function(){return i.dismissAlert(a)}})]})}))}function Bt(){try{var e=revenge.discord.design.Design;return e?.TableRow?e:void 0}catch{return}}function Vt({label:e,description:n,children:r}){var{View:i,Text:a}=revenge.react.ReactNative;return(0,t.jsxs)(i,{style:{gap:8,paddingHorizontal:16,paddingVertical:12},children:[(0,t.jsx)(a,{style:{fontSize:16,fontWeight:`600`,color:`#9a9aa2`},children:e}),r,n?(0,t.jsx)(a,{style:{fontSize:12,color:`#9a9aa2`,opacity:.8},children:n}):null]})}function Ht({label:e,description:n,children:r}){var{View:i}=revenge.react.ReactNative,a=Bt();if(!a)return(0,t.jsx)(Vt,{label:e,description:n,children:r});var{TableRow:o,Text:s}=a;return(0,t.jsx)(o,{label:e,subLabel:(0,t.jsxs)(i,{style:{gap:8,marginTop:8},children:[r,n?(0,t.jsx)(s,{variant:`text-sm/normal`,color:`text-muted`,children:n}):null]})})}function Ut({title:e,...n}){var r=Bt()?.TableRowGroup;if(!r){var{View:i}=revenge.react.ReactNative;return(0,t.jsx)(i,{children:(0,t.jsx)(Ht,{...n})})}return(0,t.jsx)(r,{title:e,children:(0,t.jsx)(Ht,{...n})})}function Q(e,t){try{var n=revenge.discord.flux.Stores.UserStore?.getUser?.(e),r=n?.globalName??n?.global_name??n?.username;if(r)return r}catch{}return t||`User ${e}`}function Wt(e,t,n){var r=n??e,i=k(e,Date.now(),t);return i?`${i.time}${i.otherDay?` ${i.otherDay}`:``} · ${r}`:`${r} · can't be shown here`}function Gt(){var e=q(),{TableRowGroup:n,TableRow:r}=revenge.discord.design.Design,[a,o]=revenge.react.React.useState(),[,s]=revenge.react.React.useReducer(function(e){return e+1},0);revenge.react.React.useEffect(function(){var e=setInterval(s,6e4);return function(){return clearInterval(e)}},[]);var c=Object.entries(e.people).filter(function(e){return!!e[1]}).sort(function(e,t){return Q(e[0],e[1].name).localeCompare(Q(t[0],t[1].name))});return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(n,{title:`Timezones you set (${c.length})`,hasIcons:!0,children:c.length===0?(0,t.jsx)(r,{label:`No one yet`,subLabel:`Long-press someone's message and choose Set their timezone, or add them by user ID below.`,icon:i(`UserCircleIcon`,`CompassIcon`)}):c.map(function([n,s]){return(0,t.jsx)(r,{label:Q(n,s.name),subLabel:Wt(s.zone,e.hour24,s.place),icon:i(`UserCircleIcon`,`CompassIcon`),onPress:function(){return o(a===n?void 0:n)}},n)})}),a&&e.people[a]&&(0,t.jsx)(Kt,{id:a})]})}function Kt({id:e}){var n=q(),{TableRowGroup:r,TableRow:o}=revenge.discord.design.Design,s=n.people[e],c=Q(e,s?.name);return(0,t.jsxs)(r,{title:c,hasIcons:!0,children:[(0,t.jsx)(o,{label:`Change timezone`,subLabel:s?s.place??A(s.zone):void 0,icon:i(`PencilIcon`,`ic_edit`),onPress:function(){return Ot(e,c)}}),(0,t.jsx)(o,{label:`Remove`,subLabel:n.sharedLookup?`Their time goes back to the shared list, if they are on it.`:void 0,variant:`danger`,icon:a(`TrashIcon`),onPress:function(){return zt({title:`Remove ${c}?`,body:`Their local time stops showing next to their messages.`,action:`Remove`,onConfirm:function(){return rt(e,c,void 0)}})}})]})}function qt(){var e=q(),{TableRowGroup:n,TableRow:r,TextInput:a}=revenge.discord.design.Design,[o,s]=revenge.react.React.useState(``),c=o.trim(),l=/^\d{15,21}$/.test(c);return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(Ut,{label:`Add by user ID`,description:`Developer Mode lets you copy anyone's ID from their profile.`,children:(0,t.jsx)(a,{placeholder:`123456789012345678`,value:o,onChange:s,keyboardType:`number-pad`})}),(0,t.jsxs)(n,{hasIcons:!0,children:[(0,t.jsx)(r,{label:`Choose their timezone`,icon:i(`ClockIcon`,`PlusSmallIcon`),arrow:!0,disabled:!l,onPress:function(){Ot(c,Q(c)),s(``)}}),e.sharedLookup&&(0,t.jsx)(r,{label:`Look them up again`,subLabel:`Ask the shared list about this ID now.`,icon:i(`RefreshIcon`,`ArrowAngleLeftUpIcon`),disabled:!l,onPress:function(){Ke(c),xt(`Looking them up…`,`TimezonesRefetchToast`)}})]})]})}function Jt({api:e}){nt(e?.jsonStorage),ie();var n=q(),{Page:r}=revenge.components,{ScrollView:a,View:o}=revenge.react.ReactNative,{Stack:s,Card:l,Text:u,TableRowGroup:d,TableSwitchRow:f}=revenge.discord.design.Design;return(0,t.jsx)(r,{children:(0,t.jsx)(a,{contentContainerStyle:{paddingBottom:c()},children:(0,t.jsxs)(s,{spacing:24,children:[(0,t.jsx)(l,{variant:`secondary`,border:`none`,children:(0,t.jsxs)(o,{style:{paddingHorizontal:16,paddingVertical:12},children:[(0,t.jsx)(u,{color:`text-default`,variant:`text-md/semibold`,children:`Their time, beside their messages`}),(0,t.jsx)(u,{color:`text-muted`,variant:`text-sm/normal`,style:{marginTop:8},children:`Long-press someone's message to set their timezone. Only you see it.`})]})}),!D()&&(0,t.jsx)(u,{color:`text-feedback-critical`,variant:`text-sm/normal`,children:`This Discord build can't work out city timezones, so only offsets like +5:30 show.`}),(0,t.jsxs)(d,{title:`Chat`,hasIcons:!0,children:[(0,t.jsx)(f,{label:`Show in chat`,subLabel:`Their local time after the timestamp on their messages.`,icon:i(`ClockIcon`,`ic_clock`),value:n.showInChat,onValueChange:function(e){return J({showInChat:e})}}),(0,t.jsx)(f,{label:`24-hour time`,subLabel:n.hour24?`15:02`:`3:02 PM`,icon:i(`TimerIcon`,`ClockIcon`),value:n.hour24,onValueChange:function(e){return J({hour24:e})}}),(0,t.jsx)(f,{label:`Show their day`,subLabel:`Add the weekday when it's a different day for them, like 3:02 AM Tue.`,icon:i(`CalendarIcon`,`ClockIcon`),value:n.showDay,onValueChange:function(e){return J({showDay:e})}})]}),(0,t.jsxs)(d,{title:`Lookups`,hasIcons:!0,children:[(0,t.jsx)(f,{label:`Use the shared timezone list`,subLabel:`For people you haven't set, ask timezonedb.catvibers.me, where people add their own timezone. Sends it the IDs of people whose messages you see.`,icon:i(`GlobeEarthIcon`,`ic_link`),value:n.sharedLookup,onValueChange:function(e){return J({sharedLookup:e})}}),(0,t.jsx)(f,{label:`Search places online`,subLabel:`Find any town or city when picking a timezone, through Open-Meteo. Sends only what you type. Countries and big cities work without it.`,icon:i(`MagnifyingGlassIcon`,`CompassIcon`),value:n.placeSearch,onValueChange:function(e){return J({placeSearch:e})}})]}),(0,t.jsx)(Gt,{}),(0,t.jsx)(qt,{})]})})})}var Yt=`[Timezones]`;function $(e,t,n){try{e(n())}catch(e){m(`${Yt} ${t} failed:`,e)}}return e.default=plugin({jsonStorage:{load:!0,default:B},start(e){if(p(e.plugin),e.cleanup(function(){return p(void 0)}),e.plugin.startedLate){e.plugin.requireReload();return}var{cleanup:t,jsonStorage:n}=e;tt(n),t(function(){return tt(void 0)}),Xe(),t(Ze),$(t,`changelog`,function(){return ne(e,fe)}),$(t,`message cache`,ve),$(t,`chat timestamp`,mt),$(t,`message sheet`,Rt)},stop(e){Ze(),e.plugin.requireReload()},SettingsComponent:Jt}),e})({},revenge.react.ReactJSXRuntime);